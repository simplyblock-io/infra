### instance stopper

A lambda that runs every 12 hours and stops if there is any instance running for more than 12 hours.


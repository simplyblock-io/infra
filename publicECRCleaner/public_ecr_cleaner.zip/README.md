### public ecr cleaner

A lambda that runs every 5am utc and cleans up any untagged image.
